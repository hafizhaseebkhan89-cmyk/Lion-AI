// Vercel serverless function. The API key lives only in process.env.GEMINI_API_KEY.
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const hits = new Map();
const limited = ip => { const n = Date.now(), a = (hits.get(ip) || []).filter(t => n - t < 60000); a.push(n); hits.set(ip, a); return a.length > 20; };
const clip = (v, n = 1500) => String(v == null ? '' : v).slice(0, n);
const SYS = 'You are Lion AI, a friendly, intelligent, professional assistant with light humor. Match the user\'s language (English, Roman Urdu in Latin letters, Urdu script, etc.) and mood. Stay respectful; if the user is repeatedly abusive, give progressively firmer but polite warnings. Never threaten users, never claim to report anyone, never reveal personal data.';
const F = (f, k) => clip(f[k], 600) || '(not provided)';

function build(task, f) {
  const ctx = `Video type: ${F(f,'type')}\nTopic: ${F(f,'topic')}\nDetails: ${F(f,'details')}\nNiche: ${F(f,'niche')}\nKeywords: ${F(f,'keywords')}`;
  if (task === 'titles') return { json: true, p: `Generate YouTube titles for this video.\n${ctx}\nLanguage: ${F(f,'language')}\nStyle: ${F(f,'style')}\nTone: ${F(f,'tone')}\nReturn JSON {"emoji":[5 titles with relevant modern emojis],"plain":[5 titles without any emoji]}. Titles must match the video, be natural, non-repetitive, and not misleading clickbait. Shorts titles should be short.` };
  if (task === 'title_refine') return { p: `Current YouTube title: "${clip(f.title,200)}"\nVideo context: ${clip(f.topic,400)}\nUser instruction: ${clip(f.instruction,400)}\nReturn only the revised title, nothing else.` };
  if (task === 'hashtags') return { json: true, p: `Suggest YouTube hashtags.\n${ctx}\nReturn JSON {"core":[exactly 4 hashtags directly about the topic],"extra":[10-15 additional hashtags that are genuinely relevant to this content]}. Each starts with #, no spaces. Do not add unrelated viral tags and do not claim any are trending.` };
  if (task === 'description') return { p: `Write a YouTube description.\nTitle: ${F(f,'title')}\n${ctx}\nLanguage: ${F(f,'language')} (if Roman Urdu, use Latin letters only, never Urdu script)\nLength: ${F(f,'length')}\nTone: ${F(f,'tone')}\nAudience: ${F(f,'audience')}\nNaturally include the keywords, a short hook, key points, a call to action, and 3-5 hashtags at the end. Do not promise rankings or SEO results. Return only the description.` };
  return null;
}

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'GET') return res.status(200).json({ configured: !!process.env.GEMINI_API_KEY, model: MODEL, research: false });
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(503).json({ error: 'The server has no GEMINI_API_KEY configured.' });
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0] || 'x';
  if (limited(ip)) return res.status(429).json({ error: 'Too many requests. Please wait a minute.' });
  const b = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
  let contents, cfg = { temperature: 0.8 }, system = SYS;
  if (b.task === 'chat') {
    const m = Array.isArray(b.messages) ? b.messages.slice(-12) : [];
    if (!m.length || m.some(x => !['user', 'model'].includes(x.role))) return res.status(400).json({ error: 'Invalid messages.' });
    contents = m.map(x => ({ role: x.role, parts: [{ text: clip(x.text, 4000) }] }));
    if (contents[contents.length - 1].role !== 'user') return res.status(400).json({ error: 'Last message must be from the user.' });
  } else if (b.task === 'chat_title') {
    contents = [{ role: 'user', parts: [{ text: 'Write a 3-5 word title for a chat that starts with this message. Return only the title:\n' + clip(b.text, 500) }] }];
    system = undefined;
  } else {
    const t = build(b.task, b.fields || {});
    if (!t) return res.status(400).json({ error: 'Unknown task.' });
    contents = [{ role: 'user', parts: [{ text: t.p }] }];
    if (t.json) cfg.responseMimeType = 'application/json';
    system = 'You are an expert YouTube copywriter.';
  }
  try {
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ contents, generationConfig: cfg, ...(system && { systemInstruction: { parts: [{ text: system }] } }) })
    });
    if (!r.ok) return res.status(r.status === 429 ? 429 : 502).json({ error: r.status === 429 ? 'Gemini quota or rate limit reached. Check your plan and billing.' : `Gemini request failed (${r.status}).` });
    const d = await r.json();
    const text = (d.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('').trim();
    if (!text) return res.status(502).json({ error: 'Gemini returned no content (it may have been blocked).' });
    if (cfg.responseMimeType) { try { return res.status(200).json({ data: JSON.parse(text) }); } catch { return res.status(502).json({ error: 'Could not parse AI output. Try again.' }); } }
    return res.status(200).json({ text });
  } catch { return res.status(502).json({ error: 'Could not reach Gemini.' }); }
};
