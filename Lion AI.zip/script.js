const $ = s => document.querySelector(s);
const KEY = 'lionai.chats';
let chats = [], cur = null, busy = false;
try { chats = JSON.parse(localStorage.getItem(KEY) || '[]'); } catch {}
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(chats)); } catch {} };
const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const copy = (t, btn) => navigator.clipboard.writeText(t).then(() => { if (btn) { const o = btn.textContent; btn.textContent = 'Copied'; setTimeout(() => btn.textContent = o, 1200); } });

async function api(body) {
  const r = await fetch('/api/gemini', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || `Request failed (${r.status})`);
  return d;
}

function openDashboard() { $('#welcomeScreen').style.display = 'none'; $('#mainInterface').style.display = 'flex'; newChat(); }
window.openDashboard = openDashboard;

function view(chat) { $('#vChat').classList.toggle('hidden', !chat); $('#vOther').classList.toggle('hidden', chat); }
function other(html) { view(false); $('#vOther').innerHTML = html; $('#vOther').parentElement.scrollTop = 0; }

/* ---------- Chat ---------- */
function newChat() {
  cur = null; view(true);
  $('#vChat').innerHTML = '<div id="msgs"></div><div class="composer"><textarea id="inp" rows="2" placeholder="Message Lion AI"></textarea><button class="btn" id="send">Send</button></div>';
  $('#send').onclick = send;
  $('#inp').onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
  renderMsgs(); renderHist(); $('#inp').focus();
}
function openChat(id) { cur = chats.find(c => c.id === id); if (!cur) return; newChatShell(); renderMsgs(); renderHist(); }
function newChatShell() { const keep = cur; newChat(); cur = keep; }
function renderMsgs() {
  const box = $('#msgs'); const m = cur ? cur.messages : [];
  box.innerHTML = m.length ? '' : '<div class="empty"><h1>How can I help?</h1><p>Ask anything, in any language.</p></div>';
  m.forEach(x => add(x.role, x.text, true));
}
function add(role, text, noScroll) {
  const d = document.createElement('div'); d.className = 'm ' + role; d.textContent = text;
  if (role === 'model') { const b = document.createElement('button'); b.className = 'sm cp'; b.textContent = 'Copy'; b.onclick = () => copy(text, b); d.appendChild(b); }
  const box = $('#msgs'); const e = box.querySelector('.empty'); if (e) e.remove();
  box.appendChild(d); box.scrollTop = box.scrollHeight; return d;
}
async function send() {
  const inp = $('#inp'), text = inp.value.trim();
  if (!text || busy) return;
  if (!cur) { cur = { id: Date.now().toString(36), title: text.slice(0, 40), messages: [] }; chats.unshift(cur); }
  cur.messages.push({ role: 'user', text }); save(); inp.value = ''; add('user', text);
  busy = true; $('#send').disabled = true;
  const wait = add('model', 'Thinking…'); const c = cur;
  try {
    const d = await api({ task: 'chat', messages: c.messages.slice(-12) });
    wait.remove(); c.messages.push({ role: 'model', text: d.text }); save();
    if (cur === c) add('model', d.text);
    if (c.messages.length === 2) api({ task: 'chat_title', text }).then(t => { c.title = t.text.replace(/["\n]/g, '').slice(0, 50); save(); renderHist(); }).catch(() => {});
  } catch (e) {
    wait.remove(); c.messages.pop(); save(); inp.value = text; add('err', e.message);
  }
  busy = false; $('#send').disabled = false; renderHist();
}
function renderHist() {
  $('#hist').innerHTML = chats.length ? '' : '<div class="note" style="padding:0 12px">No conversations yet.</div>';
  chats.forEach(c => {
    const r = document.createElement('div'); r.className = 'row' + (cur && cur.id === c.id ? ' on' : '');
    r.innerHTML = `<button class="t">${esc(c.title)}</button><button class="x" title="Delete">×</button>`;
    r.children[0].onclick = () => openChat(c.id);
    r.children[1].onclick = () => { chats = chats.filter(x => x !== c); save(); if (cur === c) newChat(); else renderHist(); };
    $('#hist').appendChild(r);
  });
}

/* ---------- YouTube Studio ---------- */
const LANGS = ['English', 'Roman Urdu', 'Urdu script', 'Arabic', 'Farsi/Persian', 'Hindi', 'Spanish', 'French', 'German', 'Turkish', 'Indonesian', 'Portuguese', 'Russian', 'Bengali'];
const fld = (id, label, type = 'text', opts) => `<div class="f"><label for="${id}">${label}</label>${
  type === 'area' ? `<textarea id="${id}" rows="3"></textarea>` :
  type === 'sel' ? `<select id="${id}">${opts.map(o => `<option>${o}</option>`).join('')}</select>` : `<input id="${id}">`}</div>`;
const TYPE = fld('type', 'Video type', 'sel', ['Long Video', 'YouTube Shorts']);
const TOOLS = {
  titles: { name: 'Title Generator', desc: 'Ten title options, then refine one by chatting with the AI.',
    form: fld('topic', 'Video topic') + fld('details', 'Video details', 'area') + TYPE,
    adv: fld('language', 'Language', 'sel', LANGS) + fld('niche', 'Niche / category') + fld('style', 'Writing style') + fld('keywords', 'Target keywords') + fld('tone', 'Title tone'), btn: 'Generate titles' },
  hashtags: { name: 'Hashtag Generator', desc: 'Four core hashtags plus relevant extras.',
    form: fld('topic', 'Video topic') + fld('details', 'Video details', 'area') + TYPE + fld('niche', 'Niche / category (optional)'), adv: '', btn: 'Generate hashtags' },
  description: { name: 'Description Generator', desc: 'A complete description in your chosen language.',
    form: fld('title', 'Video title') + fld('topic', 'Video topic') + fld('details', 'Video details', 'area') + TYPE + fld('language', 'Language', 'sel', LANGS) + fld('length', 'Description length', 'sel', ['Short', 'Medium', 'Long']),
    adv: fld('niche', 'Niche / category') + fld('keywords', 'Target keywords') + fld('tone', 'Writing tone') + fld('audience', 'Target audience'), btn: 'Generate description' },
  thumbnails: { name: 'Thumbnail Generator', desc: 'Not available yet.' }
};
function studio() {
  other(`<h1>YouTube Studio</h1><p class="sub">Choose a tool.</p><div class="grid">${Object.entries(TOOLS).map(([k, t]) => `<button class="card" data-k="${k}"><b>${t.name}</b><span>${t.desc}</span></button>`).join('')}</div>`);
  document.querySelectorAll('.card').forEach(b => b.onclick = () => tool(b.dataset.k));
}
function tool(k) {
  const t = TOOLS[k];
  if (!t.form) return other(`<button class="sm back" id="bk">← Back</button><h1>${t.name}</h1><p class="sub">Not implemented in this build. It needs an image-generation model, which has to be verified against your Gemini account before it can be offered, so no placeholder results are shown.</p>`), $('#bk').onclick = studio;
  other(`<button class="sm back" id="bk">← Back</button><h1>${t.name}</h1><p class="sub">${t.desc}</p>${t.form}${t.adv ? `<details><summary>Advanced options</summary>${t.adv}</details>` : ''}<button class="btn" id="go">${t.btn}</button><div id="out"></div>`);
  $('#bk').onclick = studio;
  const run = async () => {
    const fields = {}; document.querySelectorAll('#vOther input,#vOther textarea,#vOther select').forEach(e => fields[e.id] = e.value);
    const go = $('#go'); go.disabled = true; $('#out').innerHTML = '<p class="note">Generating…</p>';
    try { const d = await api({ task: k, fields }); RENDER[k](d, fields, run); } catch (e) { $('#out').innerHTML = `<div class="m err">${esc(e.message)}</div>`; }
    go.disabled = false;
  };
  $('#go').onclick = run;
}
const RENDER = {
  titles(d, f) {
    const row = t => `<div class="item"><span>${esc(t)}</span><span class="acts"><button class="sm c">Copy</button><button class="sm s">Select</button></span></div>`;
    $('#out').innerHTML = `<div class="res"><h3>With emojis</h3>${(d.data.emoji || []).map(row).join('')}<h3>Without emojis</h3>${(d.data.plain || []).map(row).join('')}<div id="ref"></div></div>`;
    document.querySelectorAll('#out .item').forEach(it => {
      const t = it.firstChild.textContent;
      it.querySelector('.c').onclick = e => copy(t, e.target);
      it.querySelector('.s').onclick = () => { document.querySelectorAll('#out .item').forEach(x => x.classList.remove('sel')); it.classList.add('sel'); refine(t, f); };
    });
  },
  hashtags(d, f, run) {
    const core = d.data.core || [], extra = d.data.extra || [], tag = h => `<span class="tag">${esc(h)}</span>`;
    $('#out').innerHTML = `<div class="res"><p class="note">AI-generated relevant suggestions. These are not verified trends; live trend research is not configured.</p><h3>Core (4)</h3><div class="tags">${core.map(tag).join('')}</div><h3>More relevant hashtags</h3><div class="tags">${extra.map(tag).join('')}</div>
    <div class="acts" style="margin-top:14px"><button class="sm" id="c4">Copy first four</button><button class="sm" id="ca">Copy all</button><button class="sm" id="rg">Regenerate</button></div></div>`;
    document.querySelectorAll('.tag').forEach(el => el.onclick = () => copy(el.textContent, null));
    $('#c4').onclick = e => copy(core.join(' '), e.target); $('#ca').onclick = e => copy(core.concat(extra).join(' '), e.target); $('#rg').onclick = run;
  },
  description(d, f, run) {
    $('#out').innerHTML = `<div class="res"><label class="note" for="dt">Editable preview</label><textarea id="dt" rows="14">${esc(d.text)}</textarea><div class="acts"><button class="sm" id="cd">Copy description</button><button class="sm" id="ch">Copy hashtags only</button><button class="sm" id="rg">Regenerate</button></div></div>`;
    $('#cd').onclick = e => copy($('#dt').value, e.target); $('#rg').onclick = run;
    $('#ch').onclick = e => copy(($('#dt').value.match(/#[\p{L}\p{N}_]+/gu) || []).join(' '), e.target);
  }
};
function refine(title, f) {
  $('#ref').innerHTML = `<h3>Edit selected title</h3><div class="item sel"><span id="cur">${esc(title)}</span><span class="acts"><button class="sm" id="cc">Copy</button></span></div>
  <div class="composer" style="margin-top:8px"><input id="ins" placeholder="e.g. shorten it, add an emoji, make it Roman Urdu"><button class="btn" id="ap">Apply</button></div><div id="rerr"></div>`;
  $('#cc').onclick = e => copy($('#cur').textContent, e.target);
  const ap = async () => {
    const instruction = $('#ins').value.trim(); if (!instruction) return;
    $('#ap').disabled = true; $('#rerr').innerHTML = '';
    try { const d = await api({ task: 'title_refine', fields: { title: $('#cur').textContent, instruction, topic: f.topic + ' ' + f.details } }); $('#cur').textContent = d.text; $('#ins').value = ''; }
    catch (e) { $('#rerr').innerHTML = `<div class="m err">${esc(e.message)}</div>`; }
    $('#ap').disabled = false;
  };
  $('#ap').onclick = ap; $('#ins').onkeydown = e => { if (e.key === 'Enter') ap(); };
  $('#ins').focus();
}

/* ---------- Settings (only real, working items) ---------- */
async function settings() {
  other(`<h1>Settings</h1><p class="sub">Only features that work in this build are active.</p>
  <div class="sec"><h3>AI provider</h3><p id="st" class="note">Checking server…</p></div>
  <div class="sec"><h3>Chat history</h3><p class="note">Conversations are saved in this browser only (localStorage), not on a server.</p><button class="sm" id="clr">Clear all history</button></div>
  <div class="sec"><h3>Internet research</h3><span class="st">Not configured</span><p class="note">Hashtags are AI suggestions, never verified trends.</p></div>
  <div class="sec"><h3>Account, login and security</h3><span class="st">Not implemented</span><p class="note">There are no accounts. Abuse protection is a per-IP rate limit on the server.</p></div>
  <div class="sec"><h3>Theme, language, backups, maintenance mode</h3><span class="st">Not implemented</span></div>
  <div class="sec"><h3>About</h3><p class="note">Lion AI 1.0. An independent platform, not a Google product. Powered by the Gemini API.</p></div>`);
  $('#clr').onclick = () => { if (confirm('Delete all conversations?')) { chats = []; save(); cur = null; renderHist(); } };
  try { const r = await (await fetch('/api/gemini')).json(); $('#st').innerHTML = r.configured ? `<span class="st ok">Connected</span> Model: ${esc(r.model)}. The key is stored on the server and never shown here.` : '<span class="st">Key missing</span> Set GEMINI_API_KEY on the server.'; }
  catch { $('#st').innerHTML = '<span class="st">Backend unreachable</span> Run with <code>vercel dev</code> or deploy.'; }
}

$('#nNew').onclick = newChat; $('#nStudio').onclick = studio; $('#nSet').onclick = settings;
