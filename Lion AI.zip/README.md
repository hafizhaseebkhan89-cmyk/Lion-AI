# Lion AI

Static frontend (index.html, style.css, script.js) + one serverless function (api/gemini.js) that calls Gemini. The key exists only as a server environment variable.

## Run / deploy (Vercel recommended)
1. Create a Gemini key at https://aistudio.google.com/apikey (check your quota/billing).
2. `npm i -g vercel`, then in this folder run `vercel`, and answer the prompts.
3. In Vercel > Project > Settings > Environment Variables add `GEMINI_API_KEY` (and optionally `GEMINI_MODEL`, default `gemini-2.5-flash`). Redeploy: `vercel --prod`.
4. Local test: copy `.env.example` to `.env`, run `vercel dev`.
5. Verify backend: open `https://YOUR-SITE/api/gemini`. You should see `{"configured":true,...}`. Then chat once and open Settings: it should show "Connected".

## Favicon
`favicon.svg` is your exact logo. PNG sizes (16/32/48) could not be generated in the build sandbox. Export them from favicon.svg (e.g. realfavicongenerator.net) and name them `favicon-16.png`, `favicon-32.png`, `favicon-48.png`.

## Status
Implemented, needs GEMINI_API_KEY: Lion AI chat, chat titles, Title / Hashtag / Description generators, title refinement.
Implemented, no key needed: welcome screen, sidebar, history (browser localStorage), delete/clear history, copy buttons, settings status page.
Not implemented: Thumbnail Generator, accounts/login, server-side history, live trend research, theme/language switching, backups, maintenance mode, most of the requested Settings sections (shown honestly as "Not implemented").

## Testing report
Done: JS syntax check of both files; backend validation paths run with mocked requests (missing key 503, bad task 400, bad messages 400, health GET 200).
NOT done: any real Gemini call, in-browser UI click-through, different screen sizes, deployed site. Please test these yourself after adding a key.
